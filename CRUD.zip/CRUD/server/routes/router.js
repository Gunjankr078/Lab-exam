const express = require("express");
const router = new express.Router();
const connection = require("../db/connection");


// register user
router.post("/create", (req, res) => {

    const {studentId,
        studentName,
        std,
        age,
        email,
        mobileNo} = req.body;

    if (!studentId || !studentName || !std || !age || !email || !mobileNo) {
        res.status(422).json("PLEASE FILL ALL FEILDS");
    }

    try{
        connection.query("select * from user where email = ?",email,(err,result)=>{
            if(result.length){
                res.status(422).json("EMAIL ALREADY EXIST!!")
            }else {
                connection.query("Insert into user set ?", {studentId,
                    studentName,
                    std,
                    age,
                    email,
                    mobileNo},(err,result)=>{
                        if(err){
                            console.log("error!" + err);
                        }else {
                            res.status(201).json(req.body);
                        }
                    } )
            }
        })
    }catch{

    }
});

module.exports = router; 


