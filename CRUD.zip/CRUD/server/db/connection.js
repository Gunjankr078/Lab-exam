const mysql = require("mysql2");

const connection = mysql.createConnection({
    user: "root",
    host: "localhost",
    password:"cdacacts",
    database: "server"
});

connection.connect((err)=>{
    if(err) throw err;
    console.log("DataBase Connected SuccessFully");
})

module.exports = connection;